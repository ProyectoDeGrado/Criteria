#!/bin/sh
g++ -g -lglut -lGLU -lGL -I../ $1 ../matplotpp.a  
exit

